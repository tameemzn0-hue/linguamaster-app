import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, I18nManager } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowRight, Check, Globe } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { LANGUAGES, LanguageInfo } from '@/data/languages';
import { useAuth } from '@/lib/auth';
import { router } from 'expo-router';

export default function OnboardingScreen() {
  const [step, setStep] = useState(0);
  const [nativeLang, setNativeLang] = useState<string | null>(null);
  const [targetLang, setTargetLang] = useState<string | null>(null);
  const { progress, updateProgress } = useAuth();

  const handleSelectNative = (code: string) => {
    setNativeLang(code);
  };

  const handleSelectTarget = (code: string) => {
    setTargetLang(code);
  };

  const handleContinue = async () => {
    if (step === 0 && nativeLang) {
      setStep(1);
    } else if (step === 1 && targetLang && nativeLang) {
      await updateProgress({
        nativeLanguage: nativeLang,
        targetLanguage: targetLang,
      });
      router.replace('/auth');
    }
  };

  const renderLanguageItem = ({ item }: { item: LanguageInfo }) => {
    const isSelected =
      step === 0
        ? nativeLang === item.code
        : targetLang === item.code;

    return (
      <TouchableOpacity
        style={[styles.langCard, isSelected && styles.langCardSelected]}
        onPress={() => (step === 0 ? handleSelectNative(item.code) : handleSelectTarget(item.code))}
        activeOpacity={0.7}
      >
        <Text style={styles.flag}>{item.flag}</Text>
        <View style={styles.langInfo}>
          <Text style={styles.langName}>{item.nativeName}</Text>
          <Text style={styles.langSubName}>{item.name}</Text>
        </View>
        {isSelected && (
          <View style={styles.checkCircle}>
            <Check size={20} color="#fff" />
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <LinearGradient
      colors={[colors.bg, colors.bgDark]}
      style={styles.container}
    >
      <View style={styles.content}>
        {step === 0 ? (
          <>
            <View style={styles.iconWrap}>
              <Globe size={48} color={colors.primaryLight} />
            </View>
            <Text style={styles.title}>What is your native language?</Text>
            <Text style={styles.subtitle}>
              We will use this for translations and instructions
            </Text>
          </>
        ) : (
          <>
            <View style={styles.iconWrap}>
              <Globe size={48} color={colors.secondary} />
            </View>
            <Text style={styles.title}>What do you want to learn?</Text>
            <Text style={styles.subtitle}>
              Pick the language you want to master
            </Text>
          </>
        )}

        <View style={styles.dots}>
          <View style={[styles.dot, step >= 0 && styles.dotActive]} />
          <View style={[styles.dot, step >= 1 && styles.dotActive]} />
        </View>

        <FlatList
          data={LANGUAGES}
          renderItem={renderLanguageItem}
          keyExtractor={(item) => item.code}
          numColumns={2}
          columnWrapperStyle={styles.columnWrapper}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      </View>

      <View style={styles.bottomBar}>
        {step === 1 && (
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => setStep(0)}
          >
            <Text style={styles.backText}>Back</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[
            styles.continueBtn,
            (step === 0 ? !nativeLang : !targetLang) && styles.btnDisabled,
          ]}
          onPress={handleContinue}
          disabled={step === 0 ? !nativeLang : !targetLang}
        >
          <Text style={styles.continueText}>Continue</Text>
          <ArrowRight size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: spacing.lg,
    paddingTop: spacing.xxl + 16,
  },
  iconWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(59, 130, 246, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  title: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.bold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  subtitle: {
    fontSize: fontSizes.md,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  dots: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: spacing.lg,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  dotActive: {
    backgroundColor: colors.primary,
  },
  listContent: {
    paddingBottom: 100,
  },
  columnWrapper: {
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  langCard: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: colors.surface,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  langCardSelected: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(59, 130, 246, 0.12)',
  },
  flag: {
    fontSize: 28,
  },
  langInfo: {
    flex: 1,
  },
  langName: {
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
    color: colors.text,
  },
  langSubName: {
    fontSize: fontSizes.xs,
    color: colors.textMuted,
  },
  checkCircle: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.lg,
    paddingBottom: spacing.xl + 16,
  },
  backBtn: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  backText: {
    color: colors.textSecondary,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
  },
  continueBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.primary,
    paddingVertical: spacing.lg,
    borderRadius: radius.md,
  },
  btnDisabled: {
    opacity: 0.4,
  },
  continueText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
});
