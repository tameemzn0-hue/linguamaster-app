import { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Heart } from 'lucide-react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { useAuth } from '@/lib/auth';
import { findLesson, Exercise } from '@/data/lessons';
import { FlashcardExerciseView } from '@/components/exercises/FlashcardExerciseView';
import { MatchingExerciseView } from '@/components/exercises/MatchingExerciseView';
import { SentenceExerciseView } from '@/components/exercises/SentenceExerciseView';
import { ListeningExerciseView } from '@/components/exercises/ListeningExerciseView';

export default function LessonScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { progress, updateProgress } = useAuth();

  const lesson = findLesson(progress.nativeLanguage, progress.targetLanguage, id ?? '');

  const [exerciseIndex, setExerciseIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [hearts, setHearts] = useState(progress.hearts);
  const [showResults, setShowResults] = useState(false);
  const [showOutOfHearts, setShowOutOfHearts] = useState(false);

  if (!lesson) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Lesson not found</Text>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const currentExercise = lesson.exercises[exerciseIndex];
  const progressPct = ((exerciseIndex) / lesson.exercises.length) * 100;

  const handleResult = useCallback(
    (correct: boolean) => {
      if (correct) {
        setCorrectCount((c) => c + 1);
      } else {
        const newHearts = hearts - 1;
        setHearts(newHearts);
        if (newHearts <= 0) {
          setShowOutOfHearts(true);
          return;
        }
      }
    },
    [hearts]
  );

  const handleContinue = useCallback(() => {
    if (exerciseIndex < lesson.exercises.length - 1) {
      setExerciseIndex((i) => i + 1);
    } else {
      completeLesson();
    }
  }, [exerciseIndex, lesson.exercises.length]);

  const completeLesson = useCallback(async () => {
    const earnedXp = lesson.xpReward;
    const newXp = progress.xp + earnedXp;
    const newLevel = Math.floor(newXp / 100) + 1;

    const today = new Date().toISOString().split('T')[0];
    let newStreak = progress.streak;
    if (progress.lastStreakDate !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      if (progress.lastStreakDate === yesterday || progress.lastStreakDate === null) {
        newStreak = progress.streak + 1;
      } else {
        newStreak = 1;
      }
    }

    const newBadges = [...progress.badges];
    if (newXp >= 100 && !newBadges.includes('First Steps')) newBadges.push('First Steps');
    if (newStreak >= 3 && !newBadges.includes('On Fire')) newBadges.push('On Fire');
    if (progress.completedLessons.length + 1 >= 5 && !newBadges.includes('Dedicated')) newBadges.push('Dedicated');

    const newHearts = Math.min(hearts + 1, 5);

    await updateProgress({
      xp: newXp,
      level: newLevel,
      streak: newStreak,
      lastStreakDate: today,
      hearts: newHearts,
      badges: newBadges,
      completedLessons: progress.completedLessons.includes(lesson.id)
        ? progress.completedLessons
        : [...progress.completedLessons, lesson.id],
    });

    setShowResults(true);
  }, [lesson, progress, hearts, updateProgress]);

  const handleExit = () => {
    router.back();
  };

  const handleRetry = () => {
    setExerciseIndex(0);
    setCorrectCount(0);
    setHearts(5);
    setShowOutOfHearts(false);
    setShowResults(false);
  };

  if (showOutOfHearts) {
    return (
      <LinearGradient colors={[colors.bg, colors.bgDark]} style={styles.container}>
        <View style={styles.centerContent}>
          <View style={styles.heartIcon}>
            <Heart size={48} color={colors.error} />
          </View>
          <Text style={styles.outOfHeartsTitle}>Out of Hearts</Text>
          <Text style={styles.outOfHeartsMsg}>
            You ran out of hearts. Practice to refill them!
          </Text>
          <TouchableOpacity style={styles.retryBtn} onPress={handleRetry}>
            <Text style={styles.retryText}>Try Again</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.exitBtn} onPress={handleExit}>
            <Text style={styles.exitText}>Exit Lesson</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  if (showResults) {
    const totalExercises = lesson.exercises.length;
    const accuracy = Math.round((correctCount / totalExercises) * 100);
    const isPerfect = correctCount === totalExercises;
    const isGood = accuracy >= 70;

    return (
      <LinearGradient colors={[colors.bg, colors.bgDark]} style={styles.container}>
        <View style={styles.centerContent}>
          <Text style={styles.emoji}>{isPerfect ? '🏆' : isGood ? '🎉' : '💪'}</Text>
          <Text style={styles.resultsTitle}>{isPerfect ? 'Perfect!' : isGood ? 'Great Job!' : 'Keep Going!'}</Text>
          <Text style={styles.resultsMsg}>Lesson complete! Keep practicing every day</Text>

          <View style={styles.resultsStats}>
            <View style={styles.resultStat}>
              <Text style={styles.resultStatValue}>{correctCount}/{totalExercises}</Text>
              <Text style={styles.resultStatLabel}>Correct</Text>
            </View>
            <View style={styles.resultStatDivider} />
            <View style={styles.resultStat}>
              <Text style={styles.resultStatValue}>{accuracy}%</Text>
              <Text style={styles.resultStatLabel}>Accuracy</Text>
            </View>
            <View style={styles.resultStatDivider} />
            <View style={styles.resultStat}>
              <Text style={[styles.resultStatValue, { color: colors.accent }]}>+{lesson.xpReward}</Text>
              <Text style={styles.resultStatLabel}>XP Earned</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.finishBtn} onPress={handleExit}>
            <Text style={styles.finishText}>Finish</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={[colors.bg, colors.bgDark]} style={styles.container}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={handleExit} style={styles.exitBtnSmall}>
          <X size={24} color={colors.textSecondary} />
        </TouchableOpacity>
        <View style={styles.progressBarBg}>
          <View style={[styles.progressBarFill, { width: `${progressPct}%` }]} />
        </View>
        <View style={styles.heartsDisplay}>
          <Heart size={18} color={colors.error} fill={colors.error} />
          <Text style={styles.heartsText}>{hearts}</Text>
        </View>
      </View>

      <View style={styles.exerciseContainer}>
        {currentExercise.type === 'flashcard' && (
          <FlashcardExerciseView
            exercise={currentExercise}
            targetLang={progress.targetLanguage}
            onResult={handleResult}
            onContinue={handleContinue}
          />
        )}
        {currentExercise.type === 'matching' && (
          <MatchingExerciseView
            exercise={currentExercise}
            onResult={handleResult}
            onContinue={handleContinue}
          />
        )}
        {currentExercise.type === 'sentence' && (
          <SentenceExerciseView
            exercise={currentExercise}
            targetLang={progress.targetLanguage}
            onResult={handleResult}
            onContinue={handleContinue}
          />
        )}
        {currentExercise.type === 'listening' && (
          <ListeningExerciseView
            exercise={currentExercise}
            targetLang={progress.targetLanguage}
            onResult={handleResult}
            onContinue={handleContinue}
          />
        )}
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.xxl + 8,
    paddingBottom: spacing.sm,
  },
  exitBtnSmall: {
    padding: spacing.xs,
  },
  progressBarBg: {
    flex: 1,
    height: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: radius.full,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: radius.full,
  },
  heartsDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  heartsText: {
    color: colors.text,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.bold,
  },
  exerciseContainer: {
    flex: 1,
  },
  centerContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  emoji: {
    fontSize: 72,
    marginBottom: spacing.lg,
  },
  resultsTitle: {
    fontSize: fontSizes.xxxl,
    fontWeight: fontWeights.extrabold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  resultsMsg: {
    fontSize: fontSizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  resultsStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.lg,
    marginBottom: spacing.xl,
  },
  resultStat: {
    alignItems: 'center',
  },
  resultStatValue: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  resultStatLabel: {
    fontSize: fontSizes.sm,
    color: colors.textSecondary,
    marginTop: 4,
  },
  resultStatDivider: {
    width: 1,
    height: 40,
    backgroundColor: colors.border,
  },
  finishBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.xxl,
    borderRadius: radius.md,
    width: '100%',
    maxWidth: 280,
    alignItems: 'center',
  },
  finishText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  heartIcon: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: 'rgba(239, 68, 68, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  outOfHeartsTitle: {
    fontSize: fontSizes.xxxl,
    fontWeight: fontWeights.bold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  outOfHeartsMsg: {
    fontSize: fontSizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  retryBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.md,
    width: '100%',
    maxWidth: 280,
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  retryText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  exitBtn: {
    padding: spacing.md,
  },
  exitText: {
    color: colors.textSecondary,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
  },
  errorContainer: {
    flex: 1,
    backgroundColor: colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  errorText: {
    color: colors.text,
    fontSize: fontSizes.lg,
    marginBottom: spacing.lg,
  },
  backBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.md,
  },
  backText: {
    color: '#fff',
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
  },
});
