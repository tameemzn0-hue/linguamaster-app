import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Volume2, Target, Zap, BookOpen } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { GlassCard } from '@/components/GlassCard';
import { ProgressHeader } from '@/components/ProgressHeader';
import { useAuth } from '@/lib/auth';
import { getAllLessons } from '@/data/lessons';
import { speak } from '@/lib/audio';
import { useRouter } from 'expo-router';

export default function PracticeScreen() {
  const { progress } = useAuth();
  const router = useRouter();
  const allLessons = getAllLessons(progress.nativeLanguage, progress.targetLanguage);
  const completedSet = new Set(progress.completedLessons);

  const flashcards = allLessons
    .filter((l) => !completedSet.has(l.id))
    .flatMap((l) => l.exercises.filter((e) => e.type === 'flashcard'))
    .slice(0, 10) as any[];

  const handleCardTap = (word: string) => {
    speak(word, progress.targetLanguage);
  };

  const handleStartReview = () => {
    const firstUncompleted = allLessons.find((l) => !completedSet.has(l.id));
    if (firstUncompleted) {
      router.push(`/lesson/${firstUncompleted.id}`);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.title}>Practice</Text>
      </View>
      <ProgressHeader />

      <Text style={styles.sectionTitle}>Quick Activities</Text>
      <View style={styles.activitiesRow}>
        <TouchableOpacity style={styles.activityCard} onPress={handleStartReview}>
          <View style={[styles.activityIcon, { backgroundColor: 'rgba(59, 130, 246, 0.15)' }]}>
            <BookOpen size={24} color={colors.primary} />
          </View>
          <Text style={styles.activityTitle}>Review</Text>
          <Text style={styles.activitySub}>Continue lessons</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.activityCard} onPress={handleStartReview}>
          <View style={[styles.activityIcon, { backgroundColor: 'rgba(245, 158, 11, 0.15)' }]}>
            <Zap size={24} color={colors.accent} />
          </View>
          <Text style={styles.activityTitle}>Speed Drill</Text>
          <Text style={styles.activitySub}>Beat the clock</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.activityCard} onPress={handleStartReview}>
          <View style={[styles.activityIcon, { backgroundColor: 'rgba(16, 185, 129, 0.15)' }]}>
            <Target size={24} color={colors.secondary} />
          </View>
          <Text style={styles.activityTitle}>Daily Goal</Text>
          <Text style={styles.activitySub}>{progress.dailyGoal} XP</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>Word Flashcards</Text>
      <Text style={styles.sectionSub}>Tap any card to hear pronunciation</Text>

      {flashcards.length > 0 ? (
        <View style={styles.flashcardGrid}>
          {flashcards.map((card, i) => (
            <TouchableOpacity
              key={i}
              style={styles.miniCard}
              onPress={() => handleCardTap(card.word)}
              activeOpacity={0.7}
            >
              <Volume2 size={16} color={colors.primaryLight} />
              <Text style={styles.miniWord}>{card.word}</Text>
              <Text style={styles.miniTranslation}>{card.translation}</Text>
            </TouchableOpacity>
          ))}
        </View>
      ) : (
        <GlassCard style={styles.emptyCard}>
          <Text style={styles.emptyText}>All caught up! Complete more lessons to unlock new words.</Text>
        </GlassCard>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  content: {
    paddingBottom: spacing.xxl,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xxl + 16,
    paddingBottom: spacing.sm,
  },
  title: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  sectionTitle: {
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
    color: colors.text,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  sectionSub: {
    fontSize: fontSizes.sm,
    color: colors.textSecondary,
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  activitiesRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  activityCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  activityIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activityTitle: {
    fontSize: fontSizes.sm,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  activitySub: {
    fontSize: fontSizes.xs,
    color: colors.textMuted,
  },
  flashcardGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  miniCard: {
    width: '48%',
    flexGrow: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  miniWord: {
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  miniTranslation: {
    fontSize: fontSizes.sm,
    color: colors.textSecondary,
  },
  emptyCard: {
    marginHorizontal: spacing.md,
    alignItems: 'center',
  },
  emptyText: {
    color: colors.textSecondary,
    fontSize: fontSizes.md,
    textAlign: 'center',
  },
});
