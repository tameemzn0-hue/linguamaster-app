import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Crown, Medal, TrendingUp } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { GlassCard } from '@/components/GlassCard';
import { ProgressHeader } from '@/components/ProgressHeader';
import { useAuth } from '@/lib/auth';

interface LeaderEntry {
  rank: number;
  name: string;
  xp: number;
  isYou: boolean;
}

export default function LeaderboardScreen() {
  const { progress, user } = useAuth();

  const mockLeaders: LeaderEntry[] = [
    { rank: 1, name: 'Maria Garcia', xp: 4820, isYou: false },
    { rank: 2, name: 'Liam Chen', xp: 3950, isYou: false },
    { rank: 3, name: 'Sofia Rossi', xp: 3120, isYou: false },
    { rank: 4, name: 'Ahmed Hassan', xp: 2780, isYou: false },
    { rank: 5, name: 'Emma Wilson', xp: 2240, isYou: false },
    { rank: 6, name: 'Yuki Tanaka', xp: 1890, isYou: false },
    { rank: 7, name: 'You', xp: progress.xp, isYou: true },
    { rank: 8, name: 'Lucas Silva', xp: 920, isYou: false },
    { rank: 9, name: 'Nora Kim', xp: 540, isYou: false },
    { rank: 10, name: 'Omar Faruk', xp: 320, isYou: false },
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.title}>Ranking</Text>
      </View>
      <ProgressHeader />

      <Text style={styles.sectionTitle}>Top Learners</Text>

      <View style={styles.podiumContainer}>
        {[1, 0, 2].map((idx) => {
          const leader = mockLeaders[idx];
          const isTop = idx === 0;
          const heights = [80, 100, 64];
          const iconColors = [colors.accent, colors.primary, colors.secondary];

          return (
            <View key={leader.rank} style={styles.podiumCol}>
              {isTop && <Crown size={28} color={colors.accent} />}
              <View style={[styles.podiumAvatar, { borderColor: iconColors[idx] }]}>
                <Text style={styles.podiumInitial}>{leader.name[0]}</Text>
              </View>
              <Text style={styles.podiumName} numberOfLines={1}>{leader.name}</Text>
              <Text style={styles.podiumXP}>{leader.xp} XP</Text>
              <View style={[styles.podiumBlock, { height: heights[idx], backgroundColor: iconColors[idx] + '30', borderColor: iconColors[idx] }]}>
                <Text style={[styles.podiumRank, { color: iconColors[idx] }]}>{leader.rank}</Text>
              </View>
            </View>
          );
        })}
      </View>

      <Text style={styles.sectionTitle}>All Rankings</Text>
      <View style={styles.listContainer}>
        {mockLeaders.map((leader) => (
          <View
            key={leader.rank}
            style={[styles.rankRow, leader.isYou && styles.rankRowYou]}
          >
            <Text style={styles.rankNum}>{leader.rank}</Text>
            <View style={styles.rankAvatar}>
              <Text style={styles.rankInitial}>{leader.name[0]}</Text>
            </View>
            <Text style={styles.rankName}>
              {leader.name} {leader.isYou && <Text style={styles.youBadge}>(You)</Text>}
            </Text>
            <Text style={styles.rankXP}>{leader.xp} XP</Text>
            {leader.rank <= 3 && <Medal size={18} color={[colors.accent, colors.textSecondary, colors.secondary][leader.rank - 1]} />}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  content: {
    paddingBottom: spacing.xxl,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xxl + 16,
    paddingBottom: spacing.sm,
  },
  title: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  sectionTitle: {
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
    color: colors.text,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  podiumContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
  },
  podiumCol: {
    alignItems: 'center',
    flex: 1,
  },
  podiumAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.surfaceLight,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  podiumInitial: {
    fontSize: fontSizes.xl,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  podiumName: {
    fontSize: fontSizes.sm,
    fontWeight: fontWeights.semibold,
    color: colors.text,
    marginBottom: 2,
  },
  podiumXP: {
    fontSize: fontSizes.xs,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  podiumBlock: {
    width: '100%',
    borderRadius: radius.md,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  podiumRank: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.extrabold,
  },
  listContainer: {
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
  },
  rankRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  rankRowYou: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(59, 130, 246, 0.10)',
  },
  rankNum: {
    width: 28,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.bold,
    color: colors.textMuted,
    textAlign: 'center',
  },
  rankAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankInitial: {
    fontSize: fontSizes.md,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  rankName: {
    flex: 1,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
    color: colors.text,
  },
  youBadge: {
    color: colors.primaryLight,
    fontSize: fontSizes.sm,
  },
  rankXP: {
    fontSize: fontSizes.sm,
    fontWeight: fontWeights.semibold,
    color: colors.textSecondary,
  },
});
