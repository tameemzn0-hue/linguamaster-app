import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { LogOut, Flame, Star, BookOpen, Award, Globe, Bell, Volume2, ChevronRight } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { GlassCard } from '@/components/GlassCard';
import { ProgressHeader } from '@/components/ProgressHeader';
import { useAuth } from '@/lib/auth';
import { getLanguage } from '@/data/languages';
import { router } from 'expo-router';

export default function ProfileScreen() {
  const { progress, user, signOut } = useAuth();
  const nativeLangInfo = getLanguage(progress.nativeLanguage);
  const targetLangInfo = getLanguage(progress.targetLanguage);

  const handleLogout = () => {
    Alert.alert('Log Out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log Out', style: 'destructive', onPress: () => { signOut(); router.replace('/onboarding'); } },
    ]);
  };

  const handleChangeLanguages = () => {
    router.replace('/onboarding');
  };

  const earnedBadges = progress.badges.length > 0
    ? progress.badges
    : progress.xp > 0 ? ['First Steps'] : [];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.title}>Profile</Text>
      </View>
      <ProgressHeader />

      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {user?.email ? user.email[0].toUpperCase() : 'G'}
          </Text>
        </View>
        <View style={styles.profileInfo}>
          <Text style={styles.profileName}>
            {user?.email ?? 'Guest User'}
          </Text>
          <Text style={styles.profileType}>
            {user?.isGuest ? 'Guest Mode - Progress saved locally' : 'Signed In - Progress synced to cloud'}
          </Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Statistics</Text>
      <View style={styles.statsGrid}>
        <GlassCard style={styles.statCard}>
          <Flame size={24} color={colors.warning} />
          <Text style={styles.statValue}>{progress.streak}</Text>
          <Text style={styles.statLabel}>Day Streak</Text>
        </GlassCard>
        <GlassCard style={styles.statCard}>
          <Star size={24} color={colors.primary} />
          <Text style={styles.statValue}>{progress.xp}</Text>
          <Text style={styles.statLabel}>Total XP</Text>
        </GlassCard>
        <GlassCard style={styles.statCard}>
          <BookOpen size={24} color={colors.secondary} />
          <Text style={styles.statValue}>{progress.completedLessons.length}</Text>
          <Text style={styles.statLabel}>Lessons Done</Text>
        </GlassCard>
        <GlassCard style={styles.statCard}>
          <Award size={24} color={colors.accent} />
          <Text style={styles.statValue}>{earnedBadges.length}</Text>
          <Text style={styles.statLabel}>Badges</Text>
        </GlassCard>
      </View>

      <Text style={styles.sectionTitle}>Languages</Text>
      <GlassCard style={styles.langCard}>
        <View style={styles.langRow}>
          <View>
            <Text style={styles.langLabel}>Native Language</Text>
            <Text style={styles.langValue}>{nativeLangInfo?.flag} {nativeLangInfo?.nativeName}</Text>
          </View>
        </View>
        <View style={styles.langDivider} />
        <View style={styles.langRow}>
          <View>
            <Text style={styles.langLabel}>Learning</Text>
            <Text style={styles.langValue}>{targetLangInfo?.flag} {targetLangInfo?.nativeName}</Text>
          </View>
        </View>
      </GlassCard>

      <TouchableOpacity onPress={handleChangeLanguages} style={styles.changeBtn}>
        <Globe size={20} color={colors.primary} />
        <Text style={styles.changeBtnText}>Change Languages</Text>
        <ChevronRight size={20} color={colors.textMuted} />
      </TouchableOpacity>

      <Text style={styles.sectionTitle}>Achievements</Text>
      <View style={styles.badgesRow}>
        {earnedBadges.length > 0 ? (
          earnedBadges.map((badge, i) => (
            <View key={i} style={styles.badge}>
              <Award size={28} color={colors.accent} />
              <Text style={styles.badgeName}>{badge}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.noBadges}>Complete lessons to earn badges!</Text>
        )}
      </View>

      <Text style={styles.sectionTitle}>Settings</Text>
      <GlassCard style={styles.settingsCard}>
        <View style={styles.settingRow}>
          <Bell size={20} color={colors.textSecondary} />
          <Text style={styles.settingLabel}>Notifications</Text>
          <Text style={styles.settingValue}>Off</Text>
        </View>
        <View style={styles.settingDivider} />
        <View style={styles.settingRow}>
          <Volume2 size={20} color={colors.textSecondary} />
          <Text style={styles.settingLabel}>Sound Effects</Text>
          <Text style={styles.settingValue}>On</Text>
        </View>
      </GlassCard>

      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <LogOut size={20} color={colors.error} />
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  content: {
    paddingBottom: spacing.xxl,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xxl + 16,
    paddingBottom: spacing.sm,
  },
  title: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.lg,
    padding: spacing.lg,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.bold,
    color: '#fff',
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  profileType: {
    fontSize: fontSizes.sm,
    color: colors.textSecondary,
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
    color: colors.text,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  statCard: {
    width: '48%',
    flexGrow: 1,
    alignItems: 'center',
    gap: 8,
    padding: spacing.md,
  },
  statValue: {
    fontSize: fontSizes.xxl,
    fontWeight: fontWeights.extrabold,
    color: colors.text,
  },
  statLabel: {
    fontSize: fontSizes.sm,
    color: colors.textSecondary,
  },
  langCard: {
    marginHorizontal: spacing.md,
    gap: 0,
  },
  langRow: {
    paddingVertical: spacing.sm,
  },
  langLabel: {
    fontSize: fontSizes.xs,
    color: colors.textMuted,
    marginBottom: 4,
  },
  langValue: {
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
    color: colors.text,
  },
  langDivider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.sm,
  },
  changeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginHorizontal: spacing.md,
    marginTop: spacing.md,
    padding: spacing.md,
    backgroundColor: 'rgba(59, 130, 246, 0.10)',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.30)',
  },
  changeBtnText: {
    flex: 1,
    color: colors.primary,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
  },
  badgesRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  badge: {
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    minWidth: 80,
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  badgeName: {
    fontSize: fontSizes.xs,
    color: colors.textSecondary,
    fontWeight: fontWeights.semibold,
  },
  noBadges: {
    color: colors.textMuted,
    fontSize: fontSizes.md,
    paddingHorizontal: spacing.md,
  },
  settingsCard: {
    marginHorizontal: spacing.md,
    gap: 0,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  settingLabel: {
    flex: 1,
    color: colors.text,
    fontSize: fontSizes.md,
  },
  settingValue: {
    color: colors.textMuted,
    fontSize: fontSizes.sm,
  },
  settingDivider: {
    height: 1,
    backgroundColor: colors.border,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    justifyContent: 'center',
    marginHorizontal: spacing.md,
    marginTop: spacing.lg,
    padding: spacing.lg,
    backgroundColor: 'rgba(239, 68, 68, 0.10)',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.30)',
  },
  logoutText: {
    color: colors.error,
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.semibold,
  },
});
