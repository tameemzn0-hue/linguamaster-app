import { View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Lock, CheckCircle2, PlayCircle, ChevronRight } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { GlassCard } from '@/components/GlassCard';
import { ProgressHeader } from '@/components/ProgressHeader';
import { useAuth } from '@/lib/auth';
import { getLessons, LessonUnit, Lesson } from '@/data/lessons';
import { getLanguage } from '@/data/languages';

export default function HomeScreen() {
  const { progress } = useAuth();
  const router = useRouter();
  const units = getLessons(progress.nativeLanguage, progress.targetLanguage);
  const targetLangInfo = getLanguage(progress.targetLanguage);

  const completedSet = new Set(progress.completedLessons);

  const handleLessonPress = (lesson: Lesson, unitIndex: number, lessonIndex: number) => {
    const isCompleted = completedSet.has(lesson.id);
    const prevLessonId = lessonIndex > 0 ? units[unitIndex].lessons[lessonIndex - 1].id : null;
    const prevCompleted = !prevLessonId || completedSet.has(prevLessonId);
    if (!isCompleted && !prevCompleted) return;
    router.push(`/lesson/${lesson.id}`);
  };

  const renderUnit = ({ item: unit, index: unitIndex }: { item: LessonUnit; index: number }) => {
    return (
      <View style={styles.unitContainer}>
        <View style={[styles.unitHeader, { borderLeftColor: unit.color }]}>
          <View>
            <Text style={styles.unitTitle}>{unit.title}</Text>
            <Text style={styles.unitDesc}>{unit.description}</Text>
          </View>
          <View style={[styles.unitBadge, { backgroundColor: unit.color + '20' }]}>
            <Text style={[styles.unitBadgeText, { color: unit.color }]}>
              {unit.lessons.length} lessons
            </Text>
          </View>
        </View>

        {unit.lessons.map((lesson, lessonIndex) => {
          const isCompleted = completedSet.has(lesson.id);
          const prevLessonId = lessonIndex > 0 ? unit.lessons[lessonIndex - 1].id : null;
          const isLocked = !isCompleted && !!prevLessonId && !completedSet.has(prevLessonId);

          return (
            <TouchableOpacity
              key={lesson.id}
              onPress={() => handleLessonPress(lesson, unitIndex, lessonIndex)}
              disabled={isLocked}
              activeOpacity={0.7}
            >
              <GlassCard style={[styles.lessonCard, isLocked && styles.lessonCardLocked]}>
                <View style={styles.lessonIconWrap}>
                  <Text style={styles.lessonIcon}>{lesson.icon}</Text>
                </View>
                <View style={styles.lessonInfo}>
                  <Text style={styles.lessonTitle}>{lesson.title}</Text>
                  <Text style={styles.lessonDesc}>{lesson.description}</Text>
                  <View style={styles.lessonMeta}>
                    <Text style={styles.xpBadge}>+{lesson.xpReward} XP</Text>
                  </View>
                </View>
                {isCompleted ? (
                  <CheckCircle2 size={28} color={colors.success} />
                ) : isLocked ? (
                  <Lock size={24} color={colors.textMuted} />
                ) : (
                  <PlayCircle size={28} color={colors.primary} />
                )}
              </GlassCard>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  if (units.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyIcon}>📚</Text>
        <Text style={styles.emptyTitle}>No lessons available</Text>
        <Text style={styles.emptyMsg}>
          Lessons for {targetLangInfo?.name ?? 'this language'} are coming soon!
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.greeting}>Learning {targetLangInfo?.name}</Text>
          <Text style={styles.flag}>{targetLangInfo?.flag}</Text>
        </View>
        <ProgressHeader />
        <FlatList
          data={units}
          renderItem={renderUnit}
          keyExtractor={(item) => item.id}
          scrollEnabled={false}
          contentContainerStyle={styles.unitsList}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  scrollContent: {
    paddingBottom: spacing.xxl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xxl + 16,
    paddingBottom: spacing.sm,
  },
  greeting: {
    fontSize: fontSizes.xl,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  flag: {
    fontSize: 32,
  },
  unitsList: {
    paddingHorizontal: spacing.md,
  },
  unitContainer: {
    marginBottom: spacing.xl,
  },
  unitHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: spacing.md,
    borderLeftWidth: 4,
    marginBottom: spacing.md,
  },
  unitTitle: {
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
    color: colors.text,
  },
  unitDesc: {
    fontSize: fontSizes.sm,
    color: colors.textSecondary,
    marginTop: 2,
  },
  unitBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.sm,
  },
  unitBadgeText: {
    fontSize: fontSizes.xs,
    fontWeight: fontWeights.semibold,
  },
  lessonCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.sm,
  },
  lessonCardLocked: {
    opacity: 0.5,
  },
  lessonIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  lessonIcon: {
    fontSize: 26,
  },
  lessonInfo: {
    flex: 1,
  },
  lessonTitle: {
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
    color: colors.text,
  },
  lessonDesc: {
    fontSize: fontSizes.sm,
    color: colors.textSecondary,
    marginTop: 2,
  },
  lessonMeta: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: 6,
  },
  xpBadge: {
    fontSize: fontSizes.xs,
    fontWeight: fontWeights.bold,
    color: colors.accent,
    backgroundColor: 'rgba(245, 158, 11, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: radius.sm,
  },
  emptyContainer: {
    flex: 1,
    backgroundColor: colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: spacing.lg,
  },
  emptyTitle: {
    fontSize: fontSizes.xl,
    fontWeight: fontWeights.bold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  emptyMsg: {
    fontSize: fontSizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});
