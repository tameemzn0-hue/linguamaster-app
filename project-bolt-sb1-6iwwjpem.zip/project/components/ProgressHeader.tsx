import { View, StyleSheet, Text } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Flame, Heart, Star, TrendingUp } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { GlassCard } from './GlassCard';
import { useAuth } from '@/lib/auth';

export function ProgressHeader() {
  const { progress } = useAuth();

  const xpForCurrentLevel = progress.level * 100;
  const xpProgress = ((progress.xp % xpForCurrentLevel) / xpForCurrentLevel) * 100;

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[colors.primaryDark, colors.primary]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.headerGradient}
      >
        <View style={styles.topRow}>
          <View style={styles.levelBadge}>
            <Star size={18} color="#fff" fill="#fff" />
            <Text style={styles.levelText}>{progress.level}</Text>
          </View>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Flame size={20} color={colors.warning} fill={colors.warning} />
              <Text style={styles.statValue}>{progress.streak}</Text>
            </View>
            <View style={styles.statItem}>
              <Heart size={20} color={colors.error} fill={colors.error} />
              <Text style={styles.statValue}>{progress.hearts}</Text>
            </View>
            <View style={styles.statItem}>
              <TrendingUp size={20} color={colors.success} />
              <Text style={styles.statValue}>{progress.xp}</Text>
            </View>
          </View>
        </View>
        <View style={styles.xpBarContainer}>
          <View style={styles.xpBarBg}>
            <View style={[styles.xpBarFill, { width: `${Math.min(xpProgress, 100)}%` }]} />
          </View>
          <Text style={styles.xpLabel}>
            {progress.xp % xpForCurrentLevel} / {xpForCurrentLevel} XP
          </Text>
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: spacing.md,
    marginVertical: spacing.sm,
    borderRadius: radius.lg,
    overflow: 'hidden',
  },
  headerGradient: {
    padding: spacing.lg,
    borderRadius: radius.lg,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
  },
  levelText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  statsRow: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statValue: {
    color: '#fff',
    fontSize: fontSizes.md,
    fontWeight: fontWeights.bold,
  },
  xpBarContainer: {
    gap: 6,
  },
  xpBarBg: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: radius.full,
    overflow: 'hidden',
  },
  xpBarFill: {
    height: '100%',
    backgroundColor: '#fff',
    borderRadius: radius.full,
  },
  xpLabel: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: fontSizes.xs,
    fontWeight: fontWeights.medium,
  },
});
