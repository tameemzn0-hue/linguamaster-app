import { ReactNode } from 'react';
import { View, StyleSheet, ViewStyle, StyleProp, Platform } from 'react-native';
import { BlurView } from 'expo-blur';
import { colors, radius, shadows } from '@/lib/theme';

interface GlassCardProps {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
  intensity?: number;
  noPadding?: boolean;
}

export function GlassCard({ children, style, intensity = 40, noPadding }: GlassCardProps) {
  if (Platform.OS === 'web') {
    return (
      <View
        style={[
          styles.webGlass,
          noPadding && { padding: 0 },
          style as ViewStyle,
        ]}
      >
        {children}
      </View>
    );
  }

  return (
    <View style={[styles.container, style as ViewStyle]}>
      <BlurView intensity={intensity} style={styles.blur}>
        {children}
      </BlurView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: radius.lg,
    overflow: 'hidden',
    ...(shadows?.glass as object),
  },
  blur: {
    padding: 16,
    borderRadius: radius.lg,
    backgroundColor: colors.glassBg,
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  webGlass: {
    padding: 16,
    borderRadius: radius.lg,
    backgroundColor: 'rgba(255, 255, 255, 0.06)',
    borderWidth: 1,
    borderColor: colors.glassBorder,
    backdropFilter: 'blur(20px)',
    WebkitBackdropFilter: 'blur(20px)',
    ...(shadows?.glass as object),
  } as ViewStyle,
});
