import { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Volume2, Check, X } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { speak } from '@/lib/audio';
import { ListeningExercise } from '@/data/lessons';

interface ListeningExerciseViewProps {
  exercise: ListeningExercise;
  targetLang: string;
  onResult: (correct: boolean) => void;
  onContinue: () => void;
}

export function ListeningExerciseView({
  exercise,
  targetLang,
  onResult,
  onContinue,
}: ListeningExerciseViewProps) {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [wasCorrect, setWasCorrect] = useState(false);

  useEffect(() => {
    setSelectedIdx(null);
    setAnswered(false);
  }, [exercise]);

  const handlePlay = useCallback(() => {
    speak(exercise.audioText, targetLang);
  }, [exercise.audioText, targetLang]);

  const handleSelect = useCallback(
    (idx: number) => {
      if (answered) return;
      setSelectedIdx(idx);
      const isCorrect = idx === exercise.correctIndex;
      setWasCorrect(isCorrect);
      setAnswered(true);
      onResult(isCorrect);
    },
    [answered, exercise.correctIndex, onResult]
  );

  return (
    <View style={styles.container}>
      <Text style={styles.instruction}>Listen and select what you heard</Text>

      <TouchableOpacity style={styles.audioButton} onPress={handlePlay} activeOpacity={0.7}>
        <Volume2 size={40} color={colors.primaryLight} />
        <Text style={styles.audioLabel}>Tap to play</Text>
      </TouchableOpacity>

      <View style={styles.optionsContainer}>
        {exercise.options.map((option, idx) => {
          const isSelected = selectedIdx === idx;
          const isCorrectOption = idx === exercise.correctIndex;

          let style = styles.option;
          if (answered) {
            if (isCorrectOption) style = { ...style, ...styles.correctOption };
            else if (isSelected) style = { ...style, ...styles.incorrectOption };
          } else if (isSelected) {
            style = { ...style, ...styles.selectedOption };
          }

          return (
            <TouchableOpacity
              key={idx}
              onPress={() => handleSelect(idx)}
              disabled={answered}
              style={style}
            >
              <Text style={styles.optionText}>{option}</Text>
              {answered && isCorrectOption && <Check size={20} color={colors.success} />}
              {answered && isSelected && !isCorrectOption && <X size={20} color={colors.error} />}
            </TouchableOpacity>
          );
        })}
      </View>

      {answered && (
        <View style={styles.resultContainer}>
          <View style={[styles.resultBadge, wasCorrect ? styles.correctBadge : styles.incorrectBadge]}>
            <Text style={styles.resultText}>{wasCorrect ? 'Correct!' : 'Incorrect'}</Text>
          </View>
          <TouchableOpacity style={styles.continueBtn} onPress={onContinue}>
            <Text style={styles.continueText}>Continue</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: spacing.lg,
    alignItems: 'center',
  },
  instruction: {
    color: colors.textSecondary,
    fontSize: fontSizes.sm,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  audioButton: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(59, 130, 246, 0.15)',
    borderWidth: 2,
    borderColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: spacing.xl,
  },
  audioLabel: {
    color: colors.primaryLight,
    fontSize: fontSizes.sm,
    fontWeight: fontWeights.medium,
  },
  optionsContainer: {
    width: '100%',
    gap: spacing.sm,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceLight,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedOption: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(59, 130, 246, 0.15)',
  },
  correctOption: {
    borderColor: colors.success,
    backgroundColor: 'rgba(34, 197, 94, 0.15)',
  },
  incorrectOption: {
    borderColor: colors.error,
    backgroundColor: 'rgba(239, 68, 68, 0.15)',
  },
  optionText: {
    color: colors.text,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.medium,
    flex: 1,
  },
  resultContainer: {
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.xl,
    width: '100%',
  },
  resultBadge: {
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
  },
  correctBadge: {
    backgroundColor: 'rgba(34, 197, 94, 0.2)',
  },
  incorrectBadge: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  resultText: {
    color: colors.text,
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  continueBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.md,
    width: '100%',
    maxWidth: 280,
    alignItems: 'center',
  },
  continueText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
});
