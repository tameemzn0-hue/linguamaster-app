import { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { Volume2, Check, X, RotateCcw } from 'lucide-react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withSequence,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { speak } from '@/lib/audio';
import { FlashcardExercise } from '@/data/lessons';

interface FlashcardExerciseViewProps {
  exercise: FlashcardExercise;
  targetLang: string;
  onResult: (correct: boolean) => void;
  onContinue: () => void;
}

export function FlashcardExerciseView({
  exercise,
  targetLang,
  onResult,
  onContinue,
}: FlashcardExerciseViewProps) {
  const [flipped, setFlipped] = useState(false);
  const [answered, setAnswered] = useState(false);
  const [wasCorrect, setWasCorrect] = useState(false);

  const flipValue = useSharedValue(0);
  const scaleValue = useSharedValue(1);

  useEffect(() => {
    flipValue.value = withSpring(flipped ? 180 : 0, { damping: 15, stiffness: 150 });
  }, [flipped]);

  const frontStyle = useAnimatedStyle(() => ({
    opacity: interpolate(flipValue.value, [0, 90, 180], [1, 0, 1]),
    transform: [
      { perspective: 1000 },
      { rotateY: `${flipValue.value}deg` },
    ],
  }));

  const handleFlip = useCallback(() => {
    if (!answered) setFlipped((f) => !f);
  }, [answered]);

  const handlePlayAudio = useCallback(() => {
    speak(exercise.word, targetLang);
    scaleValue.value = withSequence(
      withTiming(1.3, { duration: 150 }),
      withSpring(1, { damping: 12 })
    );
  }, [exercise.word, targetLang]);

  const handleAnswer = useCallback(
    (correct: boolean) => {
      setAnswered(true);
      setWasCorrect(correct);
      onResult(correct);
    },
    [onResult]
  );

  const audioScale = useAnimatedStyle(() => ({
    transform: [{ scale: scaleValue.value }],
  }));

  return (
    <View style={styles.container}>
      <Text style={styles.instruction}>Tap card to flip</Text>

      <TouchableOpacity
        activeOpacity={1}
        onPress={handleFlip}
        disabled={answered}
        style={styles.cardWrapper}
      >
        <Animated.View style={[styles.card, frontStyle]}>
          <TouchableOpacity
            style={styles.audioButton}
            onPress={(e) => {
              e.stopPropagation?.();
              handlePlayAudio();
            }}
          >
            <Animated.View style={audioScale}>
              <Volume2 size={28} color={colors.primaryLight} />
            </Animated.View>
          </TouchableOpacity>
          <Text style={styles.cardWord}>{exercise.word}</Text>
          <Text style={styles.cardPronunciation}>{exercise.pronunciation}</Text>
        </Animated.View>
      </TouchableOpacity>

      {flipped && !answered && (
        <View style={styles.translationContainer}>
          <Text style={styles.translationLabel}>Translation</Text>
          <Text style={styles.translationText}>{exercise.translation}</Text>
          <View style={styles.answerRow}>
            <TouchableOpacity
              style={[styles.answerBtn, styles.incorrectBtn]}
              onPress={() => handleAnswer(false)}
            >
              <X size={24} color={colors.error} />
              <Text style={styles.answerBtnText}>Don't know</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.answerBtn, styles.correctBtn]}
              onPress={() => handleAnswer(true)}
            >
              <Check size={24} color={colors.success} />
              <Text style={styles.answerBtnText}>Got it</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {answered && (
        <View style={styles.resultContainer}>
          <View style={[styles.resultBadge, wasCorrect ? styles.correctBadge : styles.incorrectBadge]}>
            <Text style={styles.resultText}>{wasCorrect ? 'Correct!' : "Don't know"}</Text>
          </View>
          <TouchableOpacity style={styles.continueBtn} onPress={onContinue}>
            <Text style={styles.continueText}>Continue</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.lg,
  },
  instruction: {
    color: colors.textSecondary,
    fontSize: fontSizes.sm,
    marginBottom: spacing.lg,
  },
  cardWrapper: {
    width: '100%',
    maxWidth: 320,
    height: 280,
  },
  card: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.surfaceLight,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: colors.glassBorder,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.md,
  },
  audioButton: {
    padding: spacing.md,
    borderRadius: radius.full,
    backgroundColor: 'rgba(59, 130, 246, 0.15)',
  },
  cardWord: {
    fontSize: fontSizes.xxxl,
    fontWeight: fontWeights.bold,
    color: colors.text,
    textAlign: 'center',
  },
  cardPronunciation: {
    fontSize: fontSizes.md,
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  translationContainer: {
    marginTop: spacing.lg,
    alignItems: 'center',
    gap: spacing.sm,
    width: '100%',
  },
  translationLabel: {
    color: colors.textMuted,
    fontSize: fontSizes.sm,
  },
  translationText: {
    color: colors.text,
    fontSize: fontSizes.xl,
    fontWeight: fontWeights.semibold,
  },
  answerRow: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  answerBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    borderWidth: 2,
  },
  correctBtn: {
    borderColor: colors.success,
    backgroundColor: 'rgba(34, 197, 94, 0.1)',
  },
  incorrectBtn: {
    borderColor: colors.error,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  answerBtnText: {
    color: colors.text,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
  },
  resultContainer: {
    marginTop: spacing.lg,
    alignItems: 'center',
    gap: spacing.md,
    width: '100%',
  },
  resultBadge: {
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
  },
  correctBadge: {
    backgroundColor: 'rgba(34, 197, 94, 0.2)',
  },
  incorrectBadge: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  resultText: {
    color: colors.text,
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  continueBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.md,
    width: '100%',
    maxWidth: 280,
    alignItems: 'center',
  },
  continueText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
});
