import { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Check, X } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { MatchingExercise } from '@/data/lessons';

interface MatchingExerciseViewProps {
  exercise: MatchingExercise;
  onResult: (correct: boolean) => void;
  onContinue: () => void;
}

interface MatchItem {
  id: number;
  text: string;
  side: 'left' | 'right';
  matched: boolean;
  pairId: number;
}

export function MatchingExerciseView({
  exercise,
  onResult,
  onContinue,
}: MatchingExerciseViewProps) {
  const [items, setItems] = useState<MatchItem[]>([]);
  const [selected, setSelected] = useState<MatchItem | null>(null);
  const [wrongPair, setWrongPair] = useState<[number, number] | null>(null);
  const [matchedCount, setMatchedCount] = useState(0);
  const [answered, setAnswered] = useState(false);

  useEffect(() => {
    const leftItems: MatchItem[] = exercise.pairs.map((p, i) => ({
      id: i,
      text: p.left,
      side: 'left',
      matched: false,
      pairId: i,
    }));
    const rightItems: MatchItem[] = exercise.pairs.map((p, i) => ({
      id: i + 100,
      text: p.right,
      side: 'right',
      matched: false,
      pairId: i,
    }));
    const shuffled = [...rightItems].sort(() => Math.random() - 0.5);
    setItems([...leftItems, ...shuffled]);
    setMatchedCount(0);
  }, [exercise]);

  const handleSelect = useCallback(
    (item: MatchItem) => {
      if (item.matched || answered) return;

      if (!selected) {
        setSelected(item);
        return;
      }

      if (selected.side === item.side) {
        setSelected(item);
        return;
      }

      if (selected.pairId === item.pairId) {
        const updated = items.map((it) => {
          if (it.id === selected.id || it.id === item.id) {
            return { ...it, matched: true };
          }
          return it;
        });
        setItems(updated);
        setSelected(null);
        const newCount = matchedCount + 1;
        setMatchedCount(newCount);
        if (newCount === exercise.pairs.length) {
          setAnswered(true);
          onResult(true);
        }
      } else {
        setWrongPair([selected.id, item.id]);
        setTimeout(() => {
          setWrongPair(null);
          setSelected(null);
        }, 600);
      }
    },
    [selected, items, matchedCount, exercise.pairs.length, onResult, answered]
  );

  const leftItems = items.filter((i) => i.side === 'left');
  const rightItems = items.filter((i) => i.side === 'right');

  return (
    <View style={styles.container}>
      <Text style={styles.instruction}>Match words with their translations</Text>

      <View style={styles.board}>
        <View style={styles.column}>
          {leftItems.map((item) => (
            <MatchButton
              key={item.id}
              item={item}
              selected={selected?.id === item.id}
              wrong={wrongPair?.includes(item.id) ?? false}
              onPress={() => handleSelect(item)}
            />
          ))}
        </View>
        <View style={styles.column}>
          {rightItems.map((item) => (
            <MatchButton
              key={item.id}
              item={item}
              selected={selected?.id === item.id}
              wrong={wrongPair?.includes(item.id) ?? false}
              onPress={() => handleSelect(item)}
            />
          ))}
        </View>
      </View>

      {answered && (
        <View style={styles.resultContainer}>
          <View style={styles.resultBadge}>
            <Check size={28} color={colors.success} />
            <Text style={styles.resultText}>All matched!</Text>
          </View>
          <TouchableOpacity style={styles.continueBtn} onPress={onContinue}>
            <Text style={styles.continueText}>Continue</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

function MatchButton({
  item,
  selected,
  wrong,
  onPress,
}: {
  item: MatchItem;
  selected: boolean;
  wrong: boolean;
  onPress: () => void;
}) {
  if (item.matched) {
    return (
      <View style={[styles.matchBtn, styles.matchedBtn]}>
        <Check size={20} color={colors.success} />
        <Text style={[styles.matchText, styles.matchedText]}>{item.text}</Text>
      </View>
    );
  }

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.matchBtn,
        selected && styles.selectedBtn,
        wrong && styles.wrongBtn,
      ]}
      activeOpacity={0.7}
    >
      <Text style={styles.matchText}>{item.text}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: spacing.lg,
  },
  instruction: {
    color: colors.textSecondary,
    fontSize: fontSizes.sm,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  board: {
    flexDirection: 'row',
    gap: spacing.md,
    flex: 1,
  },
  column: {
    flex: 1,
    gap: spacing.sm,
  },
  matchBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceLight,
    borderWidth: 2,
    borderColor: 'transparent',
    minHeight: 52,
  },
  selectedBtn: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(59, 130, 246, 0.15)',
  },
  wrongBtn: {
    borderColor: colors.error,
    backgroundColor: 'rgba(239, 68, 68, 0.15)',
  },
  matchedBtn: {
    opacity: 0.5,
    borderColor: colors.success,
  },
  matchText: {
    color: colors.text,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
  },
  matchedText: {
    textDecorationLine: 'line-through',
  },
  resultContainer: {
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.lg,
  },
  resultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    backgroundColor: 'rgba(34, 197, 94, 0.2)',
  },
  resultText: {
    color: colors.text,
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  continueBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.md,
    width: '100%',
    maxWidth: 280,
    alignItems: 'center',
    alignSelf: 'center',
  },
  continueText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
});
