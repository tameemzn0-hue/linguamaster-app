import { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Check, X, Volume2 } from 'lucide-react-native';
import { colors, spacing, fontSizes, fontWeights, radius } from '@/lib/theme';
import { speak } from '@/lib/audio';
import { SentenceExercise } from '@/data/lessons';

interface SentenceExerciseViewProps {
  exercise: SentenceExercise;
  targetLang: string;
  onResult: (correct: boolean) => void;
  onContinue: () => void;
}

export function SentenceExerciseView({
  exercise,
  targetLang,
  onResult,
  onContinue,
}: SentenceExerciseViewProps) {
  const [available, setAvailable] = useState<{ word: string; id: number }[]>([]);
  const [selected, setSelected] = useState<{ word: string; id: number }[]>([]);
  const [answered, setAnswered] = useState(false);
  const [wasCorrect, setWasCorrect] = useState(false);

  useEffect(() => {
    const shuffled = exercise.words
      .map((word, id) => ({ word, id }))
      .sort(() => Math.random() - 0.5);
    setAvailable(shuffled);
    setSelected([]);
    setAnswered(false);
  }, [exercise]);

  const handleSelectWord = useCallback(
    (item: { word: string; id: number }) => {
      if (answered) return;
      setAvailable((a) => a.filter((w) => w.id !== item.id));
      setSelected((s) => [...s, item]);
    },
    [answered]
  );

  const handleDeselectWord = useCallback(
    (item: { word: string; id: number }) => {
      if (answered) return;
      setSelected((s) => s.filter((w) => w.id !== item.id));
      setAvailable((a) => [...a, item].sort((a, b) => a.id - b.id));
    },
    [answered]
  );

  const handleCheck = useCallback(() => {
    const userOrder = selected.map((s) => s.id);
    const isCorrect =
      userOrder.length === exercise.correctOrder.length &&
      userOrder.every((id, i) => id === exercise.correctOrder[i]);
    setWasCorrect(isCorrect);
    setAnswered(true);
    onResult(isCorrect);
  }, [selected, exercise.correctOrder, onResult]);

  return (
    <View style={styles.container}>
      <Text style={styles.instruction}>Arrange words to form the sentence</Text>

      <View style={styles.translationBox}>
        <Text style={styles.translationText}>{exercise.translation}</Text>
      </View>

      <View style={styles.answerArea}>
        {selected.length === 0 ? (
          <Text style={styles.placeholder}>Tap words below...</Text>
        ) : (
          <View style={styles.selectedRow}>
            {selected.map((item) => (
              <TouchableOpacity
                key={item.id}
                onPress={() => handleDeselectWord(item)}
                style={styles.wordChip}
              >
                <Text style={styles.wordText}>{item.word}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      <View style={styles.divider} />

      <View style={styles.wordBank}>
        {available.map((item) => (
          <TouchableOpacity
            key={item.id}
            onPress={() => handleSelectWord(item)}
            style={styles.wordChip}
          >
            <Text style={styles.wordText}>{item.word}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {!answered ? (
        <TouchableOpacity
          style={[styles.checkBtn, selected.length === 0 && styles.disabledBtn]}
          onPress={handleCheck}
          disabled={selected.length === 0}
        >
          <Text style={styles.checkBtnText}>Check</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.resultContainer}>
          <View style={[styles.resultBadge, wasCorrect ? styles.correctBadge : styles.incorrectBadge]}>
            {wasCorrect ? <Check size={24} color={colors.success} /> : <X size={24} color={colors.error} />}
            <Text style={styles.resultText}>{wasCorrect ? 'Correct!' : 'Incorrect'}</Text>
          </View>
          {!wasCorrect && (
            <Text style={styles.correctAnswer}>
              Correct: {exercise.correctOrder.map((i) => exercise.words[i]).join(' ')}
            </Text>
          )}
          <TouchableOpacity style={styles.continueBtn} onPress={onContinue}>
            <Text style={styles.continueText}>Continue</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: spacing.lg,
  },
  instruction: {
    color: colors.textSecondary,
    fontSize: fontSizes.sm,
    textAlign: 'center',
    marginBottom: spacing.md,
  },
  translationBox: {
    backgroundColor: colors.surfaceLight,
    borderRadius: radius.md,
    padding: spacing.md,
    alignItems: 'center',
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  translationText: {
    color: colors.text,
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.semibold,
  },
  answerArea: {
    minHeight: 80,
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  placeholder: {
    color: colors.textMuted,
    fontSize: fontSizes.md,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  selectedRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    justifyContent: 'center',
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.md,
  },
  wordBank: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    justifyContent: 'center',
    minHeight: 60,
  },
  wordChip: {
    backgroundColor: colors.surfaceLight,
    borderRadius: radius.md,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  wordText: {
    color: colors.text,
    fontSize: fontSizes.md,
    fontWeight: fontWeights.semibold,
  },
  checkBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  disabledBtn: {
    opacity: 0.4,
  },
  checkBtnText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  resultContainer: {
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.lg,
  },
  resultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
  },
  correctBadge: {
    backgroundColor: 'rgba(34, 197, 94, 0.2)',
  },
  incorrectBadge: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  resultText: {
    color: colors.text,
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
  correctAnswer: {
    color: colors.textSecondary,
    fontSize: fontSizes.md,
    textAlign: 'center',
  },
  continueBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.md,
    width: '100%',
    maxWidth: 280,
    alignItems: 'center',
  },
  continueText: {
    color: '#fff',
    fontSize: fontSizes.lg,
    fontWeight: fontWeights.bold,
  },
});
