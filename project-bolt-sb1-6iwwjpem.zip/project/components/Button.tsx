import { ReactNode } from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { colors, radius, spacing, fontSizes, fontWeights } from '@/lib/theme';

interface ButtonProps {
  children: ReactNode;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'glass';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  fullWidth?: boolean;
}

export function Button({
  children,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled,
  loading,
  style,
  textStyle,
  fullWidth,
}: ButtonProps) {
  const variantStyle = variants[variant];
  const sizeStyle = sizes[size];
  const disabledStyle = disabled ? styles.disabled : null;

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
      style={[
        styles.base,
        variantStyle,
        sizeStyle,
        disabledStyle,
        fullWidth && { width: '100%' },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'ghost' ? colors.primary : colors.text} />
      ) : (
        <Text
          style={[
            styles.text,
            sizeStyle.text,
            variantStyle.text,
            textStyle,
          ]}
        >
          {children}
        </Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radius.md,
    overflow: 'hidden',
  },
  text: {
    fontWeight: fontWeights.semibold,
    textAlign: 'center',
  },
  disabled: {
    opacity: 0.4,
  },
});

const variants: Record<string, ViewStyle & { text: TextStyle }> = {
  primary: {
    backgroundColor: colors.primary,
    text: { color: '#fff' },
  },
  secondary: {
    backgroundColor: colors.secondary,
    text: { color: '#fff' },
  },
  ghost: {
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    borderColor: colors.glassBorder,
    text: { color: colors.text },
  },
  danger: {
    backgroundColor: colors.error,
    text: { color: '#fff' },
  },
  glass: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: colors.glassBorder,
    text: { color: colors.text },
  },
};

const sizes: Record<string, ViewStyle & { text: TextStyle }> = {
  sm: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    text: { fontSize: fontSizes.sm },
  },
  md: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    text: { fontSize: fontSizes.md },
  },
  lg: {
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.xl,
    text: { fontSize: fontSizes.lg },
  },
};
