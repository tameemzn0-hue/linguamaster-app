export type ExerciseType = 'flashcard' | 'matching' | 'sentence' | 'listening';

export interface FlashcardExercise {
  type: 'flashcard';
  word: string;
  translation: string;
  pronunciation: string;
  image?: string;
}

export interface MatchingExercise {
  type: 'matching';
  pairs: { left: string; right: string }[];
}

export interface SentenceExercise {
  type: 'sentence';
  words: string[];
  correctOrder: number[];
  translation: string;
}

export interface ListeningExercise {
  type: 'listening';
  audioText: string;
  translation: string;
  options: string[];
  correctIndex: number;
}

export type Exercise =
  | FlashcardExercise
  | MatchingExercise
  | SentenceExercise
  | ListeningExercise;

export interface Lesson {
  id: string;
  title: string;
  description: string;
  icon: string;
  exercises: Exercise[];
  xpReward: number;
}

export interface LessonUnit {
  id: string;
  title: string;
  description: string;
  color: string;
  lessons: Lesson[];
}

export interface LessonData {
  [key: string]: LessonUnit[];
}

const enEsGreetings: Lesson = {
  id: 'en-es-greetings',
  title: 'Greetings',
  description: 'Learn common Spanish greetings',
  icon: '👋',
  xpReward: 20,
  exercises: [
    {
      type: 'flashcard',
      word: 'Hola',
      translation: 'Hello',
      pronunciation: 'OH-la',
    },
    {
      type: 'flashcard',
      word: 'Buenos días',
      translation: 'Good morning',
      pronunciation: 'BWEH-nos DEE-as',
    },
    {
      type: 'flashcard',
      word: 'Buenas noches',
      translation: 'Good night',
      pronunciation: 'BWEH-nas NO-ches',
    },
    {
      type: 'matching',
      pairs: [
        { left: 'Hola', right: 'Hello' },
        { left: 'Gracias', right: 'Thank you' },
        { left: 'Adiós', right: 'Goodbye' },
        { left: 'Por favor', right: 'Please' },
      ],
    },
    {
      type: 'sentence',
      words: ['Buenos', 'días', 'amigo'],
      correctOrder: [0, 1, 2],
      translation: 'Good morning friend',
    },
    {
      type: 'listening',
      audioText: 'Hola, ¿cómo estás?',
      translation: 'Hello, how are you?',
      options: ['Hello, how are you?', 'Goodbye, see you later', 'Thank you very much', 'Good night friend'],
      correctIndex: 0,
    },
  ],
};

const enEsNumbers: Lesson = {
  id: 'en-es-numbers',
  title: 'Numbers 1-10',
  description: 'Count from one to ten in Spanish',
  icon: '🔢',
  xpReward: 25,
  exercises: [
    { type: 'flashcard', word: 'Uno', translation: 'One', pronunciation: 'OO-no' },
    { type: 'flashcard', word: 'Cinco', translation: 'Five', pronunciation: 'SEEN-ko' },
    { type: 'flashcard', word: 'Diez', translation: 'Ten', pronunciation: 'dee-ES' },
    {
      type: 'matching',
      pairs: [
        { left: 'Uno', right: 'One' },
        { left: 'Tres', right: 'Three' },
        { left: 'Siete', right: 'Seven' },
        { left: 'Diez', right: 'Ten' },
      ],
    },
    {
      type: 'sentence',
      words: ['Tengo', 'cinco', 'amigos'],
      correctOrder: [0, 1, 2],
      translation: 'I have five friends',
    },
    {
      type: 'listening',
      audioText: 'Tengo dos perros',
      translation: 'I have two dogs',
      options: ['I have two dogs', 'I have ten cats', 'I have five friends', 'I have three cars'],
      correctIndex: 0,
    },
  ],
};

const enEsFood: Lesson = {
  id: 'en-es-food',
  title: 'Food & Drink',
  description: 'Essential food and restaurant vocabulary',
  icon: '🍽️',
  xpReward: 30,
  exercises: [
    { type: 'flashcard', word: 'Pan', translation: 'Bread', pronunciation: 'pan' },
    { type: 'flashcard', word: 'Agua', translation: 'Water', pronunciation: 'AH-gwa' },
    { type: 'flashcard', word: 'Café', translation: 'Coffee', pronunciation: 'ka-FE' },
    {
      type: 'matching',
      pairs: [
        { left: 'Leche', right: 'Milk' },
        { left: 'Vino', right: 'Wine' },
        { left: 'Pollo', right: 'Chicken' },
        { left: 'Fruta', right: 'Fruit' },
      ],
    },
    {
      type: 'sentence',
      words: ['Quiero', 'un', 'café'],
      correctOrder: [0, 1, 2],
      translation: 'I want a coffee',
    },
    {
      type: 'listening',
      audioText: 'Me gusta el pan',
      translation: 'I like bread',
      options: ['I like bread', 'I want coffee', 'I need water', 'I love wine'],
      correctIndex: 0,
    },
  ],
};

const enEsTravel: Lesson = {
  id: 'en-es-travel',
  title: 'Travel Phrases',
  description: 'Navigate your trip with confidence',
  icon: '✈️',
  xpReward: 35,
  exercises: [
    { type: 'flashcard', word: 'Aeropuerto', translation: 'Airport', pronunciation: 'a-eh-ro-PWER-to' },
    { type: 'flashcard', word: 'Hotel', translation: 'Hotel', pronunciation: 'o-TEL' },
    { type: 'flashcard', word: 'Estación', translation: 'Station', pronunciation: 'es-ta-SYON' },
    {
      type: 'matching',
      pairs: [
        { left: 'Billete', right: 'Ticket' },
        { left: 'Maleta', right: 'Suitcase' },
        { left: 'Mapa', right: 'Map' },
        { left: 'Pasaporte', right: 'Passport' },
      ],
    },
    {
      type: 'sentence',
      words: ['¿Dónde', 'está', 'el', 'hotel?'],
      correctOrder: [0, 1, 2, 3],
      translation: 'Where is the hotel?',
    },
    {
      type: 'listening',
      audioText: '¿Dónde está el aeropuerto?',
      translation: 'Where is the airport?',
      options: ['Where is the airport?', 'Where is the hotel?', 'Where is the station?', 'Where is the map?'],
      correctIndex: 0,
    },
  ],
};

const enFrGreetings: Lesson = {
  id: 'en-fr-greetings',
  title: 'Greetings',
  description: 'Learn common French greetings',
  icon: '👋',
  xpReward: 20,
  exercises: [
    { type: 'flashcard', word: 'Bonjour', translation: 'Hello', pronunciation: 'bon-ZHOOR' },
    { type: 'flashcard', word: 'Merci', translation: 'Thank you', pronunciation: 'mer-SEE' },
    { type: 'flashcard', word: 'Au revoir', translation: 'Goodbye', pronunciation: 'o ruh-VWAR' },
    {
      type: 'matching',
      pairs: [
        { left: 'Bonjour', right: 'Hello' },
        { left: 'Merci', right: 'Thank you' },
        { left: 'Oui', right: 'Yes' },
        { left: 'Non', right: 'No' },
      ],
    },
    {
      type: 'sentence',
      words: ['Bonjour', 'mon', 'ami'],
      correctOrder: [0, 1, 2],
      translation: 'Hello my friend',
    },
    {
      type: 'listening',
      audioText: 'Bonjour, comment allez-vous?',
      translation: 'Hello, how are you?',
      options: ['Hello, how are you?', 'Goodbye, see you soon', 'Thank you very much', 'Yes, of course'],
      correctIndex: 0,
    },
  ],
};

const enFrFood: Lesson = {
  id: 'en-fr-food',
  title: 'Food & Drink',
  description: 'Essential French food vocabulary',
  icon: '🍽️',
  xpReward: 30,
  exercises: [
    { type: 'flashcard', word: 'Pain', translation: 'Bread', pronunciation: 'pan' },
    { type: 'flashcard', word: 'Eau', translation: 'Water', pronunciation: 'oh' },
    { type: 'flashcard', word: 'Café', translation: 'Coffee', pronunciation: 'ka-FAY' },
    {
      type: 'matching',
      pairs: [
        { left: 'Lait', right: 'Milk' },
        { left: 'Vin', right: 'Wine' },
        { left: 'Fromage', right: 'Cheese' },
        { left: 'Poulet', right: 'Chicken' },
      ],
    },
    {
      type: 'sentence',
      words: ['Je', 'veux', 'un', 'café'],
      correctOrder: [0, 1, 2, 3],
      translation: 'I want a coffee',
    },
    {
      type: 'listening',
      audioText: "J'aime le pain",
      translation: 'I like bread',
      options: ['I like bread', 'I want coffee', 'I need water', 'I love cheese'],
      correctIndex: 0,
    },
  ],
};

const enDeGreetings: Lesson = {
  id: 'en-de-greetings',
  title: 'Greetings',
  description: 'Learn common German greetings',
  icon: '👋',
  xpReward: 20,
  exercises: [
    { type: 'flashcard', word: 'Hallo', translation: 'Hello', pronunciation: 'HA-lo' },
    { type: 'flashcard', word: 'Danke', translation: 'Thank you', pronunciation: 'DAN-ke' },
    { type: 'flashcard', word: 'Tschüss', translation: 'Goodbye', pronunciation: 'CHUS' },
    {
      type: 'matching',
      pairs: [
        { left: 'Hallo', right: 'Hello' },
        { left: 'Ja', right: 'Yes' },
        { left: 'Nein', right: 'No' },
        { left: 'Bitte', right: 'Please' },
      ],
    },
    {
      type: 'sentence',
      words: ['Guten', 'Morgen', 'mein', 'Freund'],
      correctOrder: [0, 1, 2, 3],
      translation: 'Good morning my friend',
    },
    {
      type: 'listening',
      audioText: 'Wie geht es dir?',
      translation: 'How are you?',
      options: ['How are you?', 'What is your name?', 'Where is the hotel?', 'Thank you very much'],
      correctIndex: 0,
    },
  ],
};

const enDeFood: Lesson = {
  id: 'en-de-food',
  title: 'Food & Drink',
  description: 'Essential German food vocabulary',
  icon: '🍽️',
  xpReward: 30,
  exercises: [
    { type: 'flashcard', word: 'Brot', translation: 'Bread', pronunciation: 'brot' },
    { type: 'flashcard', word: 'Wasser', translation: 'Water', pronunciation: 'VAS-ser' },
    { type: 'flashcard', word: 'Kaffee', translation: 'Coffee', pronunciation: 'KA-fay' },
    {
      type: 'matching',
      pairs: [
        { left: 'Milch', right: 'Milk' },
        { left: 'Wein', right: 'Wine' },
        { left: 'Käse', right: 'Cheese' },
        { left: 'Huhn', right: 'Chicken' },
      ],
    },
    {
      type: 'sentence',
      words: ['Ich', 'will', 'einen', 'Kaffee'],
      correctOrder: [0, 1, 2, 3],
      translation: 'I want a coffee',
    },
    {
      type: 'listening',
      audioText: 'Ich mag Brot',
      translation: 'I like bread',
      options: ['I like bread', 'I want coffee', 'I need water', 'I love cheese'],
      correctIndex: 0,
    },
  ],
};

export const LESSON_DATA: LessonData = {
  'en-es': [
    {
      id: 'unit-basics',
      title: 'Basics',
      description: 'Start your Spanish journey',
      color: '#3B82F6',
      lessons: [enEsGreetings, enEsNumbers],
    },
    {
      id: 'unit-daily',
      title: 'Daily Life',
      description: 'Food, travel, and more',
      color: '#10B981',
      lessons: [enEsFood, enEsTravel],
    },
  ],
  'en-fr': [
    {
      id: 'unit-basics',
      title: 'Basics',
      description: 'Start your French journey',
      color: '#3B82F6',
      lessons: [enFrGreetings, enFrFood],
    },
  ],
  'en-de': [
    {
      id: 'unit-basics',
      title: 'Basics',
      description: 'Start your German journey',
      color: '#3B82F6',
      lessons: [enDeGreetings, enDeFood],
    },
  ],
};

export function getLessons(nativeLang: string, targetLang: string): LessonUnit[] {
  const key = `${nativeLang}-${targetLang}`;
  return LESSON_DATA[key] ?? [];
}

export function getAllLessons(nativeLang: string, targetLang: string): Lesson[] {
  return getLessons(nativeLang, targetLang).flatMap((u) => u.lessons);
}

export function findLesson(
  nativeLang: string,
  targetLang: string,
  lessonId: string
): Lesson | undefined {
  return getAllLessons(nativeLang, targetLang).find((l) => l.id === lessonId);
}
