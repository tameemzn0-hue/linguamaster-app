export interface TranslationStrings {
  appName: string;
  appTagline: string;
  welcome: string;
  welcomeSubtitle: string;
  chooseNative: string;
  chooseNativeSubtitle: string;
  chooseTarget: string;
  chooseTargetSubtitle: string;
  continue: string;
  back: string;
  getStarted: string;
  guestMode: string;
  signIn: string;
  signUp: string;
  email: string;
  password: string;
  signInGoogle: string;
  orContinueWith: string;
  home: string;
  practice: string;
  profile: string;
  leaderboard: string;
  startLesson: string;
  continueLearning: string;
  dailyGoal: string;
  streak: string;
  level: string;
  xp: string;
  hearts: string;
  lessons: string;
  completed: string;
  inProgress: string;
  locked: string;
  listenAndChoose: string;
  matchPairs: string;
  buildSentence: string;
  flashcards: string;
  check: string;
  continueBtn: string;
  correct: string;
  incorrect: string;
  correctAnswer: string;
  tapToHear: string;
  listen: string;
  playAudio: string;
  results: string;
  youEarned: string;
  lessonComplete: string;
  lessonCompleteMsg: string;
  exitLesson: string;
  retry: string;
  outOfHearts: string;
  outOfHeartsMsg: string;
  practiceToRefill: string;
  settings: string;
  notifications: string;
  soundEffects: string;
  logout: string;
  guestUser: string;
  progressSynced: string;
  progressLocal: string;
  achievements: string;
  badges: string;
  days: string;
  totalXP: string;
  lessonsCompleted: string;
  selectLanguage: string;
  changeLanguages: string;
  nativeLanguage: string;
  targetLanguage: string;
  noLessonsAvailable: string;
  noLessonsMsg: string;
  loading: string;
  error: string;
  tryAgain: string;
  goodJob: string;
  excellent: string;
  perfect: string;
  next: string;
  previous: string;
  finish: string;
  skip: string;
  review: string;
  dailyStreak: string;
  keepGoing: string;
  dontGiveUp: string;
  practiceMore: string;
  selectAnswer: string;
  arrangeWords: string;
  tapToFlip: string;
  matchingInstructions: string;
  sentenceInstructions: string;
  listeningInstructions: string;
  flashcardInstructions: string;
}

const enStrings: TranslationStrings = {
  appName: 'LinguaMaster',
  appTagline: 'Master Languages',
  welcome: 'Welcome',
  welcomeSubtitle: 'Learn a new language the smart way',
  chooseNative: 'What is your native language?',
  chooseNativeSubtitle: 'We will use this for translations and instructions',
  chooseTarget: 'What do you want to learn?',
  chooseTargetSubtitle: 'Pick the language you want to master',
  continue: 'Continue',
  back: 'Back',
  getStarted: 'Get Started',
  guestMode: 'Continue as Guest',
  signIn: 'Sign In',
  signUp: 'Sign Up',
  email: 'Email',
  password: 'Password',
  signInGoogle: 'Sign in with Google',
  orContinueWith: 'or continue with',
  home: 'Home',
  practice: 'Practice',
  profile: 'Profile',
  leaderboard: 'Ranking',
  startLesson: 'Start Lesson',
  continueLearning: 'Continue',
  dailyGoal: 'Daily Goal',
  streak: 'Streak',
  level: 'Level',
  xp: 'XP',
  hearts: 'Hearts',
  lessons: 'Lessons',
  completed: 'Completed',
  inProgress: 'In Progress',
  locked: 'Locked',
  listenAndChoose: 'Listen and Choose',
  matchPairs: 'Match the Pairs',
  buildSentence: 'Build the Sentence',
  flashcards: 'Flashcards',
  check: 'Check',
  continueBtn: 'Continue',
  correct: 'Correct!',
  incorrect: 'Incorrect',
  correctAnswer: 'Correct answer:',
  tapToHear: 'Tap to hear',
  listen: 'Listen',
  playAudio: 'Play Audio',
  results: 'Results',
  youEarned: 'You earned',
  lessonComplete: 'Lesson Complete!',
  lessonCompleteMsg: 'Great work! Keep practicing every day',
  exitLesson: 'Exit Lesson',
  retry: 'Try Again',
  outOfHearts: 'Out of Hearts',
  outOfHeartsMsg: 'You ran out of hearts. Practice to refill them!',
  practiceToRefill: 'Practice to refill hearts',
  settings: 'Settings',
  notifications: 'Notifications',
  soundEffects: 'Sound Effects',
  logout: 'Log Out',
  guestUser: 'Guest',
  progressSynced: 'Progress synced to cloud',
  progressLocal: 'Progress saved locally',
  achievements: 'Achievements',
  badges: 'Badges',
  days: 'days',
  totalXP: 'Total XP',
  lessonsCompleted: 'Lessons Completed',
  selectLanguage: 'Select Language',
  changeLanguages: 'Change Languages',
  nativeLanguage: 'Native Language',
  targetLanguage: 'Target Language',
  noLessonsAvailable: 'No lessons available',
  noLessonsMsg: 'Lessons for this language pair are coming soon!',
  loading: 'Loading...',
  error: 'Something went wrong',
  tryAgain: 'Try Again',
  goodJob: 'Good Job!',
  excellent: 'Excellent!',
  perfect: 'Perfect!',
  next: 'Next',
  previous: 'Previous',
  finish: 'Finish',
  skip: 'Skip',
  review: 'Review',
  dailyStreak: 'Daily Streak',
  keepGoing: 'Keep Going!',
  dontGiveUp: 'Don\'t give up!',
  practiceMore: 'Practice more to level up',
  selectAnswer: 'Select the correct answer',
  arrangeWords: 'Tap words to arrange them',
  tapToFlip: 'Tap card to flip',
  matchingInstructions: 'Match words with their translations',
  sentenceInstructions: 'Arrange words to form the sentence',
  listeningInstructions: 'Listen and select what you heard',
  flashcardInstructions: 'Study the word and its translation',
};

const arStrings: TranslationStrings = {
  appName: 'إتقان اللغات',
  appTagline: 'أتقن اللغات',
  welcome: 'مرحباً',
  welcomeSubtitle: 'تعلم لغة جديدة بالطريقة الذكية',
  chooseNative: 'ما هي لغتك الأم؟',
  chooseNativeSubtitle: 'سنستخدم هذه اللغة للترجمة والتعليمات',
  chooseTarget: 'ماذا تريد أن تتعلم؟',
  chooseTargetSubtitle: 'اختر اللغة التي تريد إتقانها',
  continue: 'متابعة',
  back: 'رجوع',
  getStarted: 'ابدأ الآن',
  guestMode: 'المتابعة كضيف',
  signIn: 'تسجيل الدخول',
  signUp: 'إنشاء حساب',
  email: 'البريد الإلكتروني',
  password: 'كلمة المرور',
  signInGoogle: 'تسجيل الدخول عبر Google',
  orContinueWith: 'أو تابع بـ',
  home: 'الرئيسية',
  practice: 'التمارين',
  profile: 'الملف',
  leaderboard: 'الترتيب',
  startLesson: 'ابدأ الدرس',
  continueLearning: 'متابعة',
  dailyGoal: 'الهدف اليومي',
  streak: 'التتابع',
  level: 'المستوى',
  xp: 'نقاط',
  hearts: 'القلوب',
  lessons: 'الدروس',
  completed: 'مكتمل',
  inProgress: 'قيد التقدم',
  locked: 'مقفل',
  listenAndChoose: 'استمع واختر',
  matchPairs: 'طابق الأزواج',
  buildSentence: 'كون الجملة',
  flashcards: 'البطاقات',
  check: 'تحقق',
  continueBtn: 'متابعة',
  correct: 'صحيح!',
  incorrect: 'خطأ',
  correctAnswer: 'الإجابة الصحيحة:',
  tapToHear: 'اضغط للاستماع',
  listen: 'استمع',
  playAudio: 'تشغيل الصوت',
  results: 'النتائج',
  youEarned: 'حصلت على',
  lessonComplete: 'اكتمل الدرس!',
  lessonCompleteMsg: 'عمل رائع! استمر في الممارسة كل يوم',
  exitLesson: 'إنهاء الدرس',
  retry: 'حاول مجدداً',
  outOfHearts: 'نفدت القلوب',
  outOfHeartsMsg: 'نفدت قلوبك. تمرن لتعبئتها من جديد!',
  practiceToRefill: 'تمرن لتعبئة القلوب',
  settings: 'الإعدادات',
  notifications: 'الإشعارات',
  soundEffects: 'المؤثرات الصوتية',
  logout: 'تسجيل الخروج',
  guestUser: 'ضيف',
  progressSynced: 'تمت مزامنة التقدم مع السحابة',
  progressLocal: 'تم حفظ التقدم محلياً',
  achievements: 'الإنجازات',
  badges: 'الأوسمة',
  days: 'أيام',
  totalXP: 'إجمالي النقاط',
  lessonsCompleted: 'الدروس المكتملة',
  selectLanguage: 'اختر اللغة',
  changeLanguages: 'تغيير اللغات',
  nativeLanguage: 'اللغة الأم',
  targetLanguage: 'اللغة المستهدفة',
  noLessonsAvailable: 'لا توجد دروس متاحة',
  noLessonsMsg: 'دروس هذه اللغة قريباً!',
  loading: 'جارٍ التحميل...',
  error: 'حدث خطأ ما',
  tryAgain: 'حاول مرة أخرى',
  goodJob: 'أحسنت!',
  excellent: 'ممتاز!',
  perfect: 'مثالي!',
  next: 'التالي',
  previous: 'السابق',
  finish: 'إنهاء',
  skip: 'تخطي',
  review: 'مراجعة',
  dailyStreak: 'التتابع اليومي',
  keepGoing: 'استمر!',
  dontGiveUp: 'لا تستسلم!',
  practiceMore: 'تمرن أكثر للارتقاء',
  selectAnswer: 'اختر الإجابة الصحيحة',
  arrangeWords: 'اضغط على الكلمات لترتيبها',
  tapToFlip: 'اضغط على البطاقة لقلبها',
  matchingInstructions: 'طابق الكلمات مع ترجماتها',
  sentenceInstructions: 'رتب الكلمات لتكوين الجملة',
  listeningInstructions: 'استمع واختر ما سمعته',
  flashcardInstructions: 'ادرس الكلمة وترجمتها',
};

const frStrings: TranslationStrings = {
  ...enStrings,
  appName: 'LinguaMaster',
  appTagline: 'Maîtrisez les langues',
  welcome: 'Bienvenue',
  welcomeSubtitle: 'Apprenez une nouvelle langue intelligemment',
  chooseNative: 'Quelle est votre langue maternelle?',
  chooseNativeSubtitle: 'Nous l\'utiliserons pour les traductions',
  chooseTarget: 'Que voulez-vous apprendre?',
  chooseTargetSubtitle: 'Choisissez la langue que vous voulez maîtriser',
  continue: 'Continuer',
  back: 'Retour',
  getStarted: 'Commencer',
  guestMode: 'Continuer en invité',
  signIn: 'Se connecter',
  signUp: 'S\'inscrire',
  home: 'Accueil',
  practice: 'Pratique',
  profile: 'Profil',
  leaderboard: 'Classement',
  startLesson: 'Commencer',
  continueLearning: 'Continuer',
  dailyGoal: 'Objectif quotidien',
  streak: 'Série',
  level: 'Niveau',
  xp: 'XP',
  hearts: 'Cœurs',
  lessons: 'Leçons',
  completed: 'Terminé',
  inProgress: 'En cours',
  locked: 'Verrouillé',
  correct: 'Correct!',
  incorrect: 'Incorrect',
  lessonComplete: 'Leçon terminée!',
  lessonCompleteMsg: 'Excellent travail! Continuez à pratiquer',
  logout: 'Déconnexion',
  guestUser: 'Invité',
  loading: 'Chargement...',
  tryAgain: 'Réessayer',
  goodJob: 'Bien joué!',
  excellent: 'Excellent!',
  perfect: 'Parfait!',
  next: 'Suivant',
  finish: 'Terminer',
  keepGoing: 'Continuez!',
  settings: 'Paramètres',
  nativeLanguage: 'Langue maternelle',
  targetLanguage: 'Langue cible',
};

const esStrings: TranslationStrings = {
  ...enStrings,
  appName: 'LinguaMaster',
  appTagline: 'Domina los idiomas',
  welcome: 'Bienvenido',
  welcomeSubtitle: 'Aprende un nuevo idioma de forma inteligente',
  chooseNative: '¿Cuál es tu idioma nativo?',
  chooseNativeSubtitle: 'Lo usaremos para traducciones e instrucciones',
  chooseTarget: '¿Qué quieres aprender?',
  chooseTargetSubtitle: 'Elige el idioma que quieres dominar',
  continue: 'Continuar',
  back: 'Atrás',
  getStarted: 'Empezar',
  guestMode: 'Continuar como invitado',
  signIn: 'Iniciar sesión',
  signUp: 'Registrarse',
  home: 'Inicio',
  practice: 'Práctica',
  profile: 'Perfil',
  leaderboard: 'Ranking',
  startLesson: 'Comenzar',
  continueLearning: 'Continuar',
  dailyGoal: 'Meta diaria',
  streak: 'Racha',
  level: 'Nivel',
  hearts: 'Corazones',
  lessons: 'Lecciones',
  completed: 'Completado',
  inProgress: 'En progreso',
  locked: 'Bloqueado',
  correct: '¡Correcto!',
  incorrect: 'Incorrecto',
  lessonComplete: '¡Lección completada!',
  lessonCompleteMsg: '¡Gran trabajo! Sigue practicando',
  logout: 'Cerrar sesión',
  guestUser: 'Invitado',
  loading: 'Cargando...',
  tryAgain: 'Intentar de nuevo',
  goodJob: '¡Bien hecho!',
  excellent: '¡Excelente!',
  perfect: '¡Perfecto!',
  next: 'Siguiente',
  finish: 'Terminar',
  keepGoing: '¡Sigue así!',
  settings: 'Ajustes',
  nativeLanguage: 'Idioma nativo',
  targetLanguage: 'Idioma objetivo',
};

export const TRANSLATIONS: Record<string, TranslationStrings> = {
  en: enStrings,
  ar: arStrings,
  fr: frStrings,
  es: esStrings,
};

export function getTranslations(lang: string): TranslationStrings {
  return TRANSLATIONS[lang] ?? enStrings;
}
