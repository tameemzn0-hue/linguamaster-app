import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from './supabase';
import { loadProgress, saveProgress, LocalProgress, defaultProgress } from './storage';

interface UserProfile {
  id: string;
  email: string | null;
  isGuest: boolean;
}

interface AuthContextValue {
  user: UserProfile | null;
  progress: LocalProgress;
  loading: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signInAsGuest: () => Promise<void>;
  signOut: () => Promise<void>;
  updateProgress: (updates: Partial<LocalProgress>) => Promise<void>;
  syncFromCloud: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [progress, setProgress] = useState<LocalProgress>(defaultProgress);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initialize();
  }, []);

  async function initialize() {
    try {
      const local = await loadProgress();
      setProgress(local);

      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email ?? null,
          isGuest: false,
        });
        await loadCloudProfile(session.user.id, local);
      } else if (local.nativeLanguage) {
        setUser({ id: 'guest', email: null, isGuest: true });
      }
    } catch (e) {
      console.warn('Auth init error:', e);
    } finally {
      setLoading(false);
    }
  }

  async function loadCloudProfile(userId: string, local: LocalProgress) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        const cloudProgress: LocalProgress = {
          nativeLanguage: data.native_language ?? local.nativeLanguage,
          targetLanguage: data.target_language ?? local.targetLanguage,
          xp: data.xp ?? 0,
          level: data.level ?? 1,
          streak: data.streak ?? 0,
          hearts: data.hearts ?? 5,
          lastStreakDate: data.last_streak_date ?? null,
          badges: data.badges ?? [],
          completedLessons: local.completedLessons,
          dailyGoal: data.daily_goal ?? 50,
          isGuest: false,
        };
        setProgress(cloudProgress);
        await saveProgress(cloudProgress);
      } else {
        await createCloudProfile(userId, local);
      }
    } catch (e) {
      console.warn('Failed to load cloud profile:', e);
    }
  }

  async function createCloudProfile(userId: string, local: LocalProgress) {
    try {
      const { error } = await supabase.from('profiles').insert({
        user_id: userId,
        native_language: local.nativeLanguage || 'en',
        target_language: local.targetLanguage || 'es',
        xp: local.xp,
        level: local.level,
        streak: local.streak,
        hearts: local.hearts,
        badges: local.badges,
        daily_goal: local.dailyGoal,
      });
      if (error) throw error;
    } catch (e) {
      console.warn('Failed to create cloud profile:', e);
    }
  }

  async function syncProfileToCloud(userId: string, p: LocalProgress) {
    try {
      const { error } = await supabase.from('profiles').upsert({
        user_id: userId,
        native_language: p.nativeLanguage,
        target_language: p.targetLanguage,
        xp: p.xp,
        level: p.level,
        streak: p.streak,
        hearts: p.hearts,
        last_streak_date: p.lastStreakDate,
        badges: p.badges,
        daily_goal: p.dailyGoal,
        updated_at: new Date().toISOString(),
      });
      if (error) throw error;
    } catch (e) {
      console.warn('Failed to sync profile to cloud:', e);
    }
  }

  async function syncLessonProgress(userId: string, lessonId: string, score: number) {
    try {
      const { error } = await supabase.from('lesson_progress').upsert({
        user_id: userId,
        lesson_id: lessonId,
        completed: true,
        score: score,
        completed_at: new Date().toISOString(),
      });
      if (error) throw error;
    } catch (e) {
      console.warn('Failed to sync lesson progress:', e);
    }
  }

  async function signIn(email: string, password: string) {
    setError(null);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      if (data.user) {
        setUser({ id: data.user.id, email: data.user.email ?? null, isGuest: false });
        await loadCloudProfile(data.user.id, progress);
      }
    } catch (e: any) {
      setError(e.message ?? 'Sign in failed');
      throw e;
    }
  }

  async function signUp(email: string, password: string) {
    setError(null);
    try {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) throw error;
      if (data.user) {
        setUser({ id: data.user.id, email: data.user.email ?? null, isGuest: false });
        await createCloudProfile(data.user.id, progress);
      }
    } catch (e: any) {
      setError(e.message ?? 'Sign up failed');
      throw e;
    }
  }

  async function signInAsGuest() {
    setError(null);
    const guestProgress = { ...progress, isGuest: true };
    setProgress(guestProgress);
    await saveProgress(guestProgress);
    setUser({ id: 'guest', email: null, isGuest: true });
  }

  async function signOut() {
    await supabase.auth.signOut();
    setUser(null);
    const fresh = { ...defaultProgress };
    setProgress(fresh);
    await saveProgress(fresh);
  }

  async function updateProgress(updates: Partial<LocalProgress>) {
    const updated = { ...progress, ...updates };
    setProgress(updated);
    await saveProgress(updated);
    if (user && !user.isGuest) {
      await syncProfileToCloud(user.id, updated);
      if (updates.completedLessons) {
        const newLesson = updates.completedLessons.find(
          (l) => !progress.completedLessons.includes(l)
        );
        if (newLesson) {
          await syncLessonProgress(user.id, newLesson, updates.xp ?? 0);
        }
      }
    }
  }

  async function syncFromCloud() {
    if (user && !user.isGuest) {
      await loadCloudProfile(user.id, progress);
    }
  }

  function clearError() {
    setError(null);
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        progress,
        loading,
        error,
        signIn,
        signUp,
        signInAsGuest,
        signOut,
        updateProgress,
        syncFromCloud,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
