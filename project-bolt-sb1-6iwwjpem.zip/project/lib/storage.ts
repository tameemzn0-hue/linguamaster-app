import { Platform } from 'react-native';

const STORAGE_KEY = 'linguamaster_state';

export interface LocalProgress {
  nativeLanguage: string;
  targetLanguage: string;
  xp: number;
  level: number;
  streak: number;
  hearts: number;
  lastStreakDate: string | null;
  badges: string[];
  completedLessons: string[];
  dailyGoal: number;
  isGuest: boolean;
}

export const defaultProgress: LocalProgress = {
  nativeLanguage: '',
  targetLanguage: '',
  xp: 0,
  level: 1,
  streak: 0,
  hearts: 5,
  lastStreakDate: null,
  badges: [],
  completedLessons: [],
  dailyGoal: 50,
  isGuest: true,
};

export async function loadProgress(): Promise<LocalProgress> {
  try {
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        return { ...defaultProgress, ...JSON.parse(raw) };
      }
    }
    return defaultProgress;
  } catch {
    return defaultProgress;
  }
}

export async function saveProgress(progress: Partial<LocalProgress>): Promise<void> {
  try {
    const current = await loadProgress();
    const updated = { ...current, ...progress };
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    }
  } catch (e) {
    console.warn('Failed to save progress:', e);
  }
}

export async function resetProgress(): Promise<void> {
  try {
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      window.localStorage.removeItem(STORAGE_KEY);
    }
  } catch (e) {
    console.warn('Failed to reset progress:', e);
  }
}

export async function clearOnboarding(): Promise<void> {
  try {
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        delete data.nativeLanguage;
        delete data.targetLanguage;
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      }
    }
  } catch (e) {
    console.warn('Failed to clear onboarding:', e);
  }
}

export { STORAGE_KEY };
