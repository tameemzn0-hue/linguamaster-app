import { Platform } from 'react-native';

let currentUtterance: SpeechSynthesisUtterance | null = null;

export function speak(text: string, lang: string = 'en'): void {
  if (Platform.OS !== 'web' || typeof window === 'undefined' || !window.speechSynthesis) {
    return;
  }

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.85;
  utterance.pitch = 1;

  const langMap: Record<string, string> = {
    en: 'en-US',
    es: 'es-ES',
    fr: 'fr-FR',
    de: 'de-DE',
    ar: 'ar-SA',
    it: 'it-IT',
    ja: 'ja-JP',
    zh: 'zh-CN',
    ko: 'ko-KR',
    pt: 'pt-PT',
    ru: 'ru-RU',
    tr: 'tr-TR',
  };

  utterance.lang = langMap[lang] ?? 'en-US';

  const voices = window.speechSynthesis.getVoices();
  const match = voices.find((v) => v.lang === utterance.lang);
  if (match) {
    utterance.voice = match;
  }

  currentUtterance = utterance;
  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking(): void {
  if (Platform.OS === 'web' && typeof window !== 'undefined' && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
  currentUtterance = null;
}

export function isSpeechSupported(): boolean {
  return Platform.OS === 'web' && typeof window !== 'undefined' && !!window.speechSynthesis;
}
